import json
import urllib.parse
import boto3
import PyPDF2
import io
import datetime

s3 = boto3.client('s3')

def lambda_handler(event, context):

    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    
    message = {"foo": "Luis"}
    client = boto3.client('sqs')
    response = client.publish(
        TargetArn= "arn:aws:sqs:us-east-2:944213679037:documentSQS",
        Message=json.dumps({'default': json.dumps(message)}),
        MessageStructure='json'
    )
    
    try:
        
        response = s3.get_object(Bucket = bucket, Key = key)
        file = response["Body"].read()
        pdfReader = PyPDF2.PdfFileReader(io.BytesIO(file))
        firstPage = pdfReader.getPage(0)
        firstPageText = firstPage.extractText()
        time = datetime.datetime.now()
        print(time.strftime('We are the "%Y-%m-%d %H:%M:%S'))
        
        
        
        print("CONTENT TYPE: " + response['ContentType'])
        return "All is OK"
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
